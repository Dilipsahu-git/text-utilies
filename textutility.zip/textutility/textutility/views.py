# Thi file made by ME----> Dilip

from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

def analyze(request):
    # get text form text-area.
    # djtext = (request.GET.get('text','default')) # before text typed data was showing in ulr.
    djtext = (request.POST.get('text','default'))

    # Check button is ON or OFF
    removepunc = (request.POST.get('removepunc','off'))
    fullcaps = (request.POST.get('fullcaps','off'))
    newlineremover = (request.POST.get('newlineremover', 'off'))
    extraspaceremover = (request.POST.get('extraspaceremover', 'off'))
    charcount = (request.POST.get('charcount', 'off'))
    
    # which checkbox is ON ?
    if removepunc == 'on':
        punctuations = '''!()-[]{=};,:'"<>./\?@#$%^&*_~'''
        analyzed = ""
        for char in djtext:
            if char not in punctuations:
                analyzed = analyzed + char
        params = {'purpose':'Remove Punctuations', 'analyzed_text': analyzed}
        return render(request, 'analyze.html', params)

    if(fullcaps == 'on'):
        analyzed = ""
        for char in djtext:
            analyzed = analyzed + char.upper()
        params = {'purpose':'change to UPPERCASE', 'analyzed_text': analyzed}
        djtext = analyzed
        # return render(request, 'analyze.html', params)

    if(newlineremover == 'on'):
        analyzed = ""
        for char in djtext:
            # if char != "\n" and char != "\r":
            if char != "\n":
                analyzed = analyzed + char
        params = {'purpose':'Newlines Remover', 'analyzed_text': analyzed}
        djtext = analyzed
        # return render(request, 'analyze.html', params)

    if(extraspaceremover == 'on'):
        analyzed = ""
        for index, char in enumerate(djtext):
            if not(djtext[index] == " " and djtext[index+1] == " "):
                analyzed = analyzed + char
        params = {'purpose':'Extra Space-remover', 'analyzed_text': analyzed}
        djtext = analyzed
        # return render(request, 'analyze.html', params)

    if(charcount == 'on'):
        analyzed = ""
        analyzed = len(djtext)
        params = {'purpose':'Charcount', 'analyzed_text': analyzed}
        djtext = analyzed
        # return render(request, 'analyze.html', params)
    
    if(removepunc == 'on' and fullcaps == 'on' and newlineremover == 'on' and extraspaceremover == 'on' and charcount == 'on'):
        return HttpResponse("Error")
    
    return render(request, 'analyze.html', params)